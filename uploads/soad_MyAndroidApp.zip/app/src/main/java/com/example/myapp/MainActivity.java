package com.example.myapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private double total = 0.0;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultText = findViewById(R.id.tv_result);

        Button btn025 = findViewById(R.id.btn_025);
        Button btn050 = findViewById(R.id.btn_050);
        Button btn075 = findViewById(R.id.btn_075);
        Button btn100 = findViewById(R.id.btn_100);
        Button btnCalculate = findViewById(R.id.btn_calculate);
        Button btnRestart = findViewById(R.id.btn_restart);

        btn025.setOnClickListener(v -> addValue(0.25));
        btn050.setOnClickListener(v -> addValue(0.50));
        btn075.setOnClickListener(v -> addValue(0.75));
        btn100.setOnClickListener(v -> addValue(1.00));

        btnCalculate.setOnClickListener(v -> calculateTotal());
        btnRestart.setOnClickListener(v -> restart());
    }

    private void addValue(double value) {
        total += value;
    }

    private void calculateTotal() {
        if (total > 0) {
            resultText.setText("Total Sum: " + String.format("%.2f", total));
        } else {
            resultText.setText("No values to calculate.");
        }
    }

    private void restart() {
        total = 0.0;
        resultText.setText("Restarted.");
    }
}
